package no.posten.eventhub.example.demo.configuration;


import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.messaging.Message;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Sinks;

import java.util.function.Consumer;
import java.util.function.Supplier;

@Log4j2
@Profile("kafka-bindings")
@Configuration
public class KafkaEventHubConfiguration {

    @Bean
    public Sinks.Many<Message<String>> many() {
        return Sinks.many().unicast().onBackpressureBuffer();
    }

    @Bean
    public Supplier<Flux<Message<String>>> supply(Sinks.Many<Message<String>> many) {
        return () -> many.asFlux()
                         .doOnNext(m -> log.info("Manually sending message {}", m))
                         .doOnError(t -> log.error("Error encountered", t));
    }

    @Bean
    public Consumer<Message<String>> consume() {
        return message -> log.info("New message received: '{}'", message.getPayload());
    }

}
