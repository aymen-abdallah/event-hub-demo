package no.posten.eventhub.example.demo.api;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Sinks;

@Log4j2
@RestController
public class EventProducerController {

    private final Sinks.Many<Message<String>> many;

    @Autowired
    public EventProducerController(final Sinks.Many<Message<String>> many) {
        this.many = many;
    }

    @PostMapping("/messages")
    public ResponseEntity<String> sendMessage(@RequestParam final String message) {
        log.info("Going to add message {} to sendMessage.", message);
        many.emitNext(MessageBuilder.withPayload(message)
                                    .build(), Sinks.EmitFailureHandler.FAIL_FAST);
        return ResponseEntity.ok(message);
    }

}