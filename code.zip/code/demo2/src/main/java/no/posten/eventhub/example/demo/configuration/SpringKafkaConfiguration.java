package no.posten.eventhub.example.demo.configuration;

import lombok.extern.log4j.Log4j2;
//import org.apache.kafka.clients.consumer.Consumer;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
//import org.apache.kafka.common.config.SaslConfigs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
// import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
// import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

@Log4j2
@Profile("spring-kafka-config")
@Configuration
public class SpringKafkaConfiguration {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServer;

    @Value("${spring.kafka.properties.sasl.jaas.config}")
    private String saslJaasConfig;

//    @Bean
//    public DefaultKafkaConsumerFactory<String, String> consumerFactory() {
//        Map<String, Object> properties = new HashMap<>();
//        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
//        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
//        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
//        properties.put(ConsumerConfig.GROUP_ID_CONFIG, "$Default");
//        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//        properties.put(ConsumerConfig.CLIENT_ID_CONFIG, "ae1fd777-2aac-4b9d-8236-8c847bb69902");
//        properties.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
//        properties.put("security.protocol", "SASL_SSL");
//        properties.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
//
//        return new DefaultKafkaConsumerFactory<>(properties);
//    }
//
//    @Bean
//    public Consumer<String, String> myConsumer(final DefaultKafkaConsumerFactory<String, String> consumerFactory) {
//        return consumerFactory.createConsumer();
//    }
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, String> eventHubKafkaListenerContainerFactory(
//            final DefaultKafkaConsumerFactory<String, String> consumerFactory) {
//        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(consumerFactory);
//        return factory;
//    }
}
