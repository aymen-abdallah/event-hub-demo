package no.posten.eventhub.example.demo.api;

import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Sinks;

import java.time.Duration;
import java.util.Collections;

@Log4j2
@RestController
public class EventProducerController {

    private static final String TOPIC_NAME = "aymen-test-hub";
    private final Sinks.Many<Message<String>> many;

    private final Consumer<String, String> consumer;

    private final ConsumerRebalanceListener consumerRebalanceListener;

    @Autowired
    public EventProducerController(final Consumer<String, String> myConsumer,
                                   final ConsumerRebalanceListener consumerRebalanceListener
                                   // final Sinks.Many<Message<String>> many
    ) {
        this.consumerRebalanceListener = consumerRebalanceListener;
        this.many = null;
        this.consumer = myConsumer;
    }

    @PostMapping("/messages")
    public ResponseEntity<String> sendMessage(@RequestParam final String message) {
        log.info("Going to add message {} to sendMessage.", message);
        many.emitNext(MessageBuilder.withPayload(message)
                                    .build(), Sinks.EmitFailureHandler.FAIL_FAST);
        return ResponseEntity.ok(message);
    }

    @PostMapping("/messages/consume")
    public ResponseEntity<Void> sendMessage() {
        //consumer.subscribe(Collections.singletonList(TOPIC_NAME), consumerRebalanceListener);
        ConsumerRecords<String, String> records = consumer.poll(Duration.ofSeconds(5));

        for (ConsumerRecord<String, String> record : records) {
            log.info("Key: " + record.key() + ", Value:" + record.value());
            log.info("Partition:" + record.partition() + ",Offset:" + record.offset());
        }

        consumer.unsubscribe();
        return ResponseEntity.noContent().build();
    }

}