package no.posten.eventhub.example.demo.kafka;

import lombok.extern.log4j.Log4j2;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Log4j2
@Component
public class MyKafkaListener {

    @KafkaListener(topics = "aymen-test-hub", containerFactory = "eventHubKafkaListenerContainerFactory")
    public void listen(@Payload String event) {
        log.info("The received message is : {}", event);
    }
}
