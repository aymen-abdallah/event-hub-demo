package no.posten.eventhub.example.demo.kafka;

import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.TopicPartition;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Log4j2
public class KafkaReplayTimestampBasedListener implements ConsumerRebalanceListener {

    private final Consumer<?, ?> consumer;
    private final Long startTimestamp;

    public KafkaReplayTimestampBasedListener(final Consumer<?, ?> consumer, final Long startTimestamp) {
        this.consumer = consumer;
        this.startTimestamp = startTimestamp;
    }

    @Override
    public void onPartitionsRevoked(Collection<TopicPartition> collection) {

    }

    @Override
    public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
        log.info("onPartitionsAssigned - consumerName: %s, partitions: %s%n", "0",
                formatPartitions(partitions));

        Map<TopicPartition, Long> timestampsToSearch = new HashMap<>();
        for (TopicPartition partition : partitions) {
            timestampsToSearch.put(partition,  startTimestamp);
        }
        // for each assigned partition, find the earliest offset in that partition with a timestamp
        // greater than or equal to the input timestamp
        consumer.assign(partitions);
        Map<TopicPartition, OffsetAndTimestamp> outOffsets = consumer.offsetsForTimes(timestampsToSearch);
        for (TopicPartition partition : partitions) {
            Long seekOffset = outOffsets.get(partition).offset();
            Long currentPosition = consumer.position(partition);
            // seek to the offset returned by the offsetsForTimes API
            // if it is beyond the current position
            if (seekOffset.compareTo(currentPosition) > 0) {
                consumer.seek(partition, seekOffset);
            }
        }
    }

    private static List<String> formatPartitions(Collection<TopicPartition> partitions) {
        return partitions.stream()
                         .map(topicPartition -> String.format("topic: %s, partition: %s", topicPartition.topic(), topicPartition.partition()))
                         .collect(Collectors.toList());
    }
}
